1. Make sure the datapath is mentioned correctly
2. code requires pytorch and transformers library to be installed