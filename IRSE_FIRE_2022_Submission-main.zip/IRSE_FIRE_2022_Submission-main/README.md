# IRSE_FIRE_2022_Submission
